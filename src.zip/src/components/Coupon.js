import React from "react";
import "./Coupon.css";

const Coupon = () => {
  return (
    <>
      <div className="coupon_card">
        <div></div>
      </div>
    </>
  );
};

<></>;
export default Coupon;
