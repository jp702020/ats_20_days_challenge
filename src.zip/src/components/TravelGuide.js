// import React from "react";
// import "./TravelGuide.css";
// import influencer from "../assets/travelInfl.jpg";
// const TravelGuide = () => {
//   return (
//     <>
//       <div className="profile_cotainer">
//         <div>
//           <div className="upper_sec">
//             <i class="bi bi-arrow-left-short" />
//             <i class="bi bi-search" />
//           </div>
//           <div className="mid_sec">
//             <div className="upper_div">
//               <div className="name_pic">
//                 <h6>ManuelRovira</h6>
//                 <i class="bi bi-patch-check-fill"></i>
//                 <div className="profil_pic">
//                   <img src={influencer} />
//                 </div>
//               </div>
//               <div className="info">
//                 <div>
//                   <h6>110</h6>
//                   <p>Post</p>
//                 </div>
//                 <div>
//                   <h6>23.6K</h6>
//                   <p>Followers</p>
//                 </div>
//                 <div>
//                   <h6>488</h6>
//                   <p>Following</p>
//                 </div>
//               </div>
//             </div>
//             <div className="bio">
//               <p>Manual James Rovira | IG Marketing</p>
//               <ul>
//                 <li>Influencer</li>
//                 <li>Public Figure</li>
//                 <li>I am Your Fashion Guide</li>
//               </ul>
//             </div>
//           </div>
//           <div className="lower_sec">
//             <div className="cat_div">
//               <div>
//                 <p>Explorre Categories</p>
//               </div>
//               <div>
//                 <i class="bi bi-three-dots"></i>
//               </div>
//             </div>
//             <div className="categories">
//               <ul>
//                 <li className="list_items">
//                   <img src={influencer} />
//                   <p>Travel</p>
//                 </li>
//                 <li className="list_items">
//                   <img src={influencer} />
//                   <p>Night</p>
//                 </li>
//                 <li className="list_items">
//                   <img src={influencer} />
//                   <p>Casual</p>
//                 </li>
//                 <li className="list_items">
//                   <img src={influencer} />
//                   <p>Festiv</p>
//                 </li>
//                 <li className="list_items">
//                   <img src={influencer} />
//                   <p>Occasion</p>
//                 </li>
//                 <li className="list_items">
//                   <img src={influencer} />
//                   <p>Party</p>
//                 </li>
//               </ul>
//             </div>
//           </div>
//         </div>
//       </div>
//       <div className="inf_grid">
//         <div className="grid_div">
//           <div className="grid_img">
//             <img src={influencer} />
//             <div className="connection">
//               <div></div>
//             </div>
//           </div>
//           <div className="grid_img">
//             <img src={influencer} />
//             <div className="connection">
//               <div></div>
//             </div>
//           </div>
//           <div className="grid_img">
//             <img src={influencer} />
//             <div className="connection">
//               <div></div>
//             </div>
//           </div>
//           <div className="grid_img">
//             <img src={influencer} />
//             <div className="connection">
//               <div></div>
//             </div>
//           </div>
//           <div className="grid_img">
//             <img src={influencer} />
//             <div className="connection">
//               <div></div>
//             </div>
//           </div>
//           <div className="grid_img">
//             <img src={influencer} />
//             <div className="connection">
//               <div></div>
//             </div>
//           </div>
//           <div className="grid_img">
//             <img src={influencer} />
//             <div className="connection">
//               <div></div>
//             </div>
//           </div>
//           <div className="grid_img">
//             <img src={influencer} />
//             <div className="connection">
//               <div></div>
//             </div>
//           </div>
//           <div className="grid_img">
//             <img src={influencer} />
//             <div className="connection">
//               <div></div>
//             </div>
//           </div>
//         </div>
//       </div>
//     </>
//   );
// };

// export default TravelGuide;
