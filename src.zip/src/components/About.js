import React from "react";
import "./About.css";

function About() {
  return <></>;
}

export default About;
