import React from "react";
import "./OpenPost.css";

const OpenPost = () => {
  return (
    <>
      <div className="open_container">
        <div className="tg1">
          <img className="group-icon" alt="" src="/group@2x.png" />
          <div className="status-bar">
            <div className="right-side">
              <img className="battery-icon" alt="" src="/battery@2x.png" />
              <img className="wifi-icon" alt="" src="/wifi@2x.png" />
              <img
                className="mobile-signal-icon"
                alt=""
                src="/mobile-signal@2x.png"
              />
              <img
                className="recording-indicator-icon"
                alt=""
                src="/recording-indicator@2x.png"
              />
            </div>
            <img className="left-side-icon" alt="" src="/left-side@2x.png" />
          </div>
          <img className="tg1-child" alt="" src="/rectangle-991@2x.png" />
          <div className="tg1-item" />
          <div className="bar">
            <div className="menu-1">
              <div className="vuesaxlinearhome-2">
                <div className="menu-11">
                  <img className="lihome-icon" alt="" src="/lihome@2x.png" />
                </div>
              </div>
              <div className="home">Home</div>
            </div>
            <div className="menu-2">
              <img className="about-icon" alt="" src="/about@2x.png" />
              <div className="home">About</div>
            </div>
            <div className="menu-3">
              <img className="about-icon" alt="" src="/chat-icon-uia@2x.png" />
              <div className="chat">Chat</div>
            </div>
            <div className="menu-4">
              <img className="lihome-icon" alt="" src="/blogpencil-1@2x.png" />
              <div className="home">Blog</div>
            </div>
            <div className="menu-5">
              <img className="lihome-icon" alt="" src="/liuser@2x.png" />
              <div className="home">Account</div>
            </div>
          </div>
          <div className="tg1-inner" />
          <b className="rs49980person">
            <span>Rs.49980</span>
            <span className="person">/person</span>
          </b>
          <div className="component-1">
            <div className="frame-parent">
              <div className="frame-wrapper">
                <div className="rectangle-parent">
                  <div className="frame-child" />
                  <b className="day-1">Day 1</b>
                </div>
              </div>
              <b className="detailed-itinerary-for">{`Detailed itinerary for 4-day trip to Himachal Pradesh `}</b>
              <div className="rectangle-group">
                <div className="frame-item" />
                <b className="day-1">Day 2</b>
              </div>
              <div className="rectangle-container">
                <div className="frame-item" />
                <b className="day-1">Day 3</b>
              </div>
              <div className="frame-div">
                <div className="frame-item" />
                <b className="day-1">Day 4</b>
              </div>
            </div>
            <div className="frame-group">
              <div className="frame-container">
                <div className="frame-parent1">
                  <div className="rectangle-parent1">
                    <div className="frame-child1" />
                    <div className="am">7:00 AM</div>
                  </div>
                  <div className="frame-child2" />
                  <img
                    className="rectangle-icon"
                    alt=""
                    src="/rectangle-1019@2x.png"
                  />
                  <div className="am-parent">
                    <b className="am1">7:00 AM</b>
                    <b className="bengaluru">Bengaluru</b>
                    <div className="departure">Departure</div>
                  </div>
                  <b className="rs20980person">
                    <span>Rs.20980</span>
                    <span className="person">/person</span>
                  </b>
                  <div className="pm-parent">
                    <b className="pm">2:00 PM</b>
                    <b className="shimla">Shimla</b>
                    <div className="arrival">Arrival</div>
                  </div>
                  <img className="arrow-icon" alt="" src="/arrow-1@2x.png" />
                  <div className="group-div">
                    <div className="group-child" />
                    <div className="sia9376">SIA9376</div>
                  </div>
                  <div className="frame-child3" />
                  <div className="view-site">View Site</div>
                  <div className="book-journey-to-container">
                    <b>{`✈️ Book Journey `}</b>
                    <span>to Shimla</span>
                  </div>
                </div>
                <div className="frame-parent2">
                  <div className="rectangle-parent2">
                    <div className="frame-child1" />
                    <b className="pm1">2:30 PM</b>
                  </div>
                  <div className="rectangle-parent3">
                    <div className="frame-child5" />
                    <img
                      className="frame-child6"
                      alt=""
                      src="/rectangle-1019@2x.png"
                    />
                    <div className="rs3200night">
                      <span>Rs.3200</span>
                      <span className="person">/night</span>
                    </div>
                    <div className="rectangle-parent4">
                      <div className="group-child" />
                      <div className="sia9377">SIA9377</div>
                    </div>
                    <div className="frame-child7" />
                    <b className="view-site1">View Site</b>
                    <div className="rectangle-parent5">
                      <div className="group-inner" />
                      <b className="hill-view">Hill View</b>
                    </div>
                    <div className="rectangle-parent6">
                      <div className="group-child1" />
                      <b className="fitness-centre">Fitness Centre</b>
                    </div>
                    <div className="rectangle-parent7">
                      <div className="group-child2" />
                      <b className="breakfast-included">Breakfast included</b>
                    </div>
                    <div className="rectangle-parent8">
                      <div className="group-inner" />
                      <b className="free-wifi">Free Wifi</b>
                    </div>
                    <div className="rectangle-parent9">
                      <div className="group-child4" />
                      <b className="restaurant">Restaurant</b>
                    </div>
                    <div className="rectangle-parent10">
                      <div className="group-child5" />
                      <b className="swimming-pool">Swimming Pool</b>
                    </div>
                    <div className="group-parent">
                      <div className="rectangle-parent11">
                        <div className="group-child6" />
                        <div className="snow-valley-resort">
                          Snow Valley Resort
                        </div>
                      </div>
                      <div className="rectangle-wrapper">
                        <div className="group-child7" />
                      </div>
                      <img className="star-icon" alt="" src="/star@2x.png" />
                      <div className="div">4.4</div>
                    </div>
                  </div>
                  <div className="accommodation-at-snow-container">
                    <b>{`🏨 Accommodation `}</b>
                    <span>at Snow Valley Resort</span>
                  </div>
                </div>
                <div className="frame-parent2">
                  <div className="rectangle-parent2">
                    <div className="frame-child1" />
                    <b className="pm1">4:00 PM</b>
                  </div>
                  <div className="frame-child2" />
                  <img
                    className="rectangle-icon"
                    alt=""
                    src="/rectangle-1019@2x.png"
                  />
                  <div className="free-parent">
                    <div className="free">Free</div>
                    <div className="rectangle-parent13">
                      <div className="group-child8" />
                      <div className="jakhu-temple">Jakhu Temple</div>
                    </div>
                    <div className="rectangle-frame">
                      <div className="group-child7" />
                    </div>
                    <img className="star-icon1" alt="" src="/star@2x.png" />
                    <div className="div1">4.8</div>
                    <div className="rectangle-parent14">
                      <div className="group-child10" />
                      <b className="timings-6am-12pm-and">{`Timings: 6AM-12PM and 4PM-8PM  `}</b>
                    </div>
                    <div className="rectangle-parent15">
                      <div className="group-child11" />
                      <b className="breakfast-included">
                        Cable car available to reach temple
                      </b>
                    </div>
                    <div className="rectangle-parent16">
                      <div className="group-child1" />
                      <b className="breakfast-included">No Dress code</b>
                    </div>
                  </div>
                  <div className="rectangle-parent17">
                    <div className="group-child13" />
                    <b className="view-site2">View Site</b>
                    <div className="rectangle-parent18">
                      <div className="group-child" />
                      <div className="sia9377">SIA9378</div>
                    </div>
                  </div>
                  <div className="accommodation-at-snow-container">
                    <b>{`🏰 Explore Attraction, `}</b>
                    <span>Jakhu Temple in Shimla</span>
                  </div>
                </div>
                <div className="frame-parent2">
                  <div className="rectangle-parent2">
                    <div className="frame-child1" />
                    <b className="pm1">6:00 PM</b>
                  </div>
                  <div className="frame-child2" />
                  <img
                    className="rectangle-icon"
                    alt=""
                    src="/rectangle-1019@2x.png"
                  />
                  <div className="free-group">
                    <div className="free1">Free</div>
                    <div className="frame-child14" />
                    <b className="view-site3">View Site</b>
                  </div>
                  <div className="rectangle-parent20">
                    <div className="group-child" />
                    <div className="sia9377">SIA9379</div>
                  </div>
                  <div className="group-container">
                    <div className="rectangle-parent21">
                      <div className="group-child8" />
                      <div className="jakhu-temple">Christ Church</div>
                    </div>
                    <div className="rectangle-frame">
                      <div className="group-child7" />
                    </div>
                    <img className="star-icon1" alt="" src="/star@2x.png" />
                    <div className="div2">4.6</div>
                    <div className="rectangle-parent22">
                      <div className="group-child10" />
                      <b className="timings-6am-12pm-and">{`Timings: 7AM-12PM and 5PM-8PM  `}</b>
                    </div>
                    <div className="rectangle-parent23">
                      <div className="group-child19" />
                      <b className="breakfast-included">Tourist attraction</b>
                    </div>
                    <div className="rectangle-parent24">
                      <div className="group-child1" />
                      <b className="breakfast-included">No Dress code</b>
                    </div>
                  </div>
                  <div className="book-journey-to-container">
                    <b>{`🏰 Explore Attraction, `}</b>
                    <span>Christ Church in Shimla</span>
                  </div>
                </div>
              </div>
              <img
                className="frame-icon"
                alt=""
                src="/frame-1000000936@2x.png"
              />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default OpenPost;
