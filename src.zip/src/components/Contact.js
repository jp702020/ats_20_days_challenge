import React from "react";
import CardScreen from "./CardScreen";

const Contact = () => {
  return (
    <div>
      <CardScreen />
    </div>
  );
};

export default Contact;
